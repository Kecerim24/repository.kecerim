import { csfd } from 'node-csfd-api';

const searchTerm = process.argv[2];
if (!searchTerm) {
    console.error('Please provide a search term as a command line argument');
    process.exit(1);
}

csfd.search(searchTerm).then((search) => console.log(JSON.stringify(search, null, 2)));