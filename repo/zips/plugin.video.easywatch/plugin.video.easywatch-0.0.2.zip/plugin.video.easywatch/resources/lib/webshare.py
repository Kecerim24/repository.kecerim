import requests
import hashlib
from passlib.hash import md5_crypt
from xml.etree import ElementTree
import json


class WebshareAPI:
    def __init__(self):
        self._base_url = "https://webshare.cz/api/"
        self._headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
        self._token = ""

    def login(self, user_name, password):
        """Logs {user_name} in Webshare API"""
        salt = self.get_salt(user_name)
        url = self._base_url + 'login/'
        password = self.hash_password(password, salt)
        data = {
                'username_or_email' : user_name,
                'password' : password,
                'keep_logged_in' : 1
                }
        response = requests.post(url, data=data, headers=self._headers)
        assert(response.status_code == 200)
        root = ElementTree.fromstring(response.content)
        assert root.find('status').text == 'OK', 'Return code was not OK, debug info: status: {}, code: {}, message: {}'.format(
                    root.find('status').text,
                    root.find('code').text,
                    root.find('message').text)
        self._token = root.find('token').text

    def hash_password(self, password, salt):
        """Creates password hash used by Webshare API"""
        password = hashlib.sha1(md5_crypt.hash(password, salt=salt).encode('utf-8')).hexdigest()
        return password

    def get_salt(self, user_name):
        """Retrieves salt for password hash from webshare.cz"""
        url = self._base_url + 'salt/'
        data = {'username_or_email' : user_name}
        response = requests.post(url, data=data, headers=self._headers)
        assert(response.status_code == 200)
        root = ElementTree.fromstring(response.content)
        assert root.find('status').text == 'OK', 'Return code was not OK, debug info: status: {}, code: {}, message: {}'.format(
                    root.find('status').text, 
                    root.find('code').text, 
                    root.find('message').text)
        return root.find('salt').text

    def get_download_link(self, file_id):
        """Query actual download link from {file_id}"""
        url = self._base_url + 'file_link/'
        data = {'ident' : file_id, 'wst' : self._token}
        response = requests.post(url, data=data, headers=self._headers)
        assert response.status_code == 200
        root = ElementTree.fromstring(response.content)
        assert root.find('status').text == 'OK', 'Return code was not OK, debug info: status: {}, code: {}, message: {}'.format(
                    root.find('status').text, 
                    root.find('code').text, 
                    root.find('message').text)

        return root.find('link').text
    
    def search(self, query, limit=20, offset=0):
        """Search for videos on webshare.cz"""
        url = self._base_url + 'search/'
        data = {'what' : query, 'limit' : limit, 'offset' : offset, 'category' : 'video'}
        response = requests.post(url, data=data, headers=self._headers)
        assert response.status_code == 200
        root = ElementTree.fromstring(response.content)
        assert root.find('status').text == 'OK', 'Return code was not OK, debug info: status: {}'.format(
                    root.find('status').text)
        
        files = []
        for file_elem in root.findall('file'):
            file_data = {
                'ident': file_elem.find('ident').text,
                'name': file_elem.find('name').text,
                'type': file_elem.find('type').text,
                'img': file_elem.find('img').text,
                'stripe': file_elem.find('stripe').text,
                'stripe_count': file_elem.find('stripe_count').text,
                'size': file_elem.find('size').text,
                'queued': file_elem.find('queued').text,
                'positive_votes': file_elem.find('positive_votes').text,
                'negative_votes': file_elem.find('negative_votes').text,
                'password': file_elem.find('password').text
            }
            files.append(file_data)
        
        return {
            'status': root.find('status').text,
            'total': root.find('total').text,
            'files': files
        }
        
if __name__ == "__main__":
    # For testing purposes
    webshare = WebshareAPI()
    webshare.login("test", "test")
    json = webshare.search("House S07E23", 5)
    print(webshare.get_download_link(json['files'][0]['ident']))