import subprocess
import json

def csfd():
    result = search_csfd(input("Hledej: "))
    typ = int(input("Typ (1 - film, 2 - seriál): "))
    if typ == 1:
        movies = result["movies"]
        for i, movie in enumerate(movies, 1):
            print(f"{i}. {movie['title']}, {movie['year']}")
        movie_choice = int(input("Vyber film (1-{}): ".format(len(movies))))
        movie = movies[movie_choice - 1]
        print_movie(movie)


    elif typ == 2:
        series = result["tvSeries"]
        for serie in series:
            print(serie["title"])
def print_movie(movie: dict):
    print(f"Název: \033[1m{movie['title']}\033[0m")
    print(f"Rok: {movie['year']}")
    print(f"URL: {movie['url']}")
    

def search_csfd(search_term: str) -> dict:
    try:
        # Run the Node.js script with the search term
        result = subprocess.run(['node', 'search.js', search_term], 
                              capture_output=True, 
                              text=True,
                              check=True)
        
        # Parse the JSON output from the Node script
        search_results = dict(json.loads(result.stdout))
        return search_results

    except subprocess.CalledProcessError as e:
        print(f"Error running search script: {e.stderr}")
        return []
    except json.JSONDecodeError as e:
        print(f"Error parsing search results: {e}")
        return []


